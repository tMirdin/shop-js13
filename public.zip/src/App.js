import MainRoutes from './MainRoutes';
import './App.css'

function App() {
    return (
        <div className="App">
            <MainRoutes />
        </div>
    );
};

export default App;